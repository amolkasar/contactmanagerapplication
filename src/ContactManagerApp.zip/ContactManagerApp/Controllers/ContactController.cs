﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ContactManagerApp.Models;
using System.Data.Entity;

namespace ContactManagerApp.Controllers
{
    public class ContactController : Controller
    {
        
        //Developed By Amol Kasar - 16/06/2021
        //Contact Email - amolrkasar@gmail.com
       
        // For Load Default Index View while run first time
        public ActionResult Index()
        {
            return View();
        }

        // For Get Conatct data from database and load into the View  
        public ActionResult GetData()
        {
            using (DBModel db = new DBModel())
            {
                List<tblContact> contactList = db.tblContacts.ToList<tblContact>();
                return Json(new { data = contactList }, JsonRequestBehavior.AllowGet);
            }
        }


        // For Loading View While Editing the record  
        [HttpGet]
        public ActionResult AddOrEdit(int id = 0)
        {
            if (id == 0)
                return View(new tblContact());
            else
            {
                using (DBModel db = new DBModel())
                {
                    return View(db.tblContacts.Where(x => x.Id==id).FirstOrDefault<tblContact>());
                }
            }
        }

        // For Add New Record and Update the data of the particular record
        [HttpPost]
        public ActionResult AddOrEdit(tblContact c)
        {
            using (DBModel db = new DBModel())
            {
                if (c.Id == 0)
                {
                    c.CreatedOn = DateTime.Now;
                    db.tblContacts.Add(c);
                    db.SaveChanges();
                    return Json(new { success = true, message = "Saved Successfully" }, JsonRequestBehavior.AllowGet);
                }
                else {
                    c.ModifiedOn = DateTime.Now;
                    db.Entry(c).State = EntityState.Modified;
                    db.SaveChanges();
                    return Json(new { success = true, message = "Updated Successfully" }, JsonRequestBehavior.AllowGet);
                }
            }


        }

        // For Delete Particular Record from Database
        [HttpPost]
        public ActionResult Delete(int id)
        {
            using (DBModel db = new DBModel())
            {
                tblContact c = db.tblContacts.Where(x => x.Id == id).FirstOrDefault<tblContact>();
                db.tblContacts.Remove(c);
                db.SaveChanges();
                return Json(new { success = true, message = "Deleted Successfully" }, JsonRequestBehavior.AllowGet);
            }
        }
    }
}